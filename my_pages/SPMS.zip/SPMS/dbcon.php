<?php
mysql_select_db('bilal',mysql_connect('localhost','root',''))or die(mysql_error());
?>
