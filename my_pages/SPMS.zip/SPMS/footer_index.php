<center>
		<footer>
           <p>All Rights Reserved 2016  by waqasmaqbool.com</p>
        <footer>
</center>