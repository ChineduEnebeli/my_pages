<?php

$email = "mahkhafx@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>